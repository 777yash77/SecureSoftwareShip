cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
